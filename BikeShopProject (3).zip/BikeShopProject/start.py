from asyncio.windows_events import NULL
from email import message
from glob import glob
import os
import psycopg2
from flask import Flask, redirect, url_for, render_template, request
import rsa
import re
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

publicKey = rsa.PublicKey(8864864214230065995202763740218556574899068353919685421281676565235580684818448523110255698019682719811712782298650452722634769219182668510002703110424729, 65537)
privateKey = rsa.PrivateKey(8864864214230065995202763740218556574899068353919685421281676565235580684818448523110255698019682719811712782298650452722634769219182668510002703110424729, 65537, 5138447926669999344275181789880869236725297292044204186698328110230392584069310658951796951190624670637471368763343696551567043315572191461868294028892689, 7179446398685968393772375702460218939053042696689799791218826447466322590177261883, 1234755957764734388111524350388830462126863373341709945592578123205576763)
global encPasw
app = Flask(__name__)

def get_db_connection():

    conn = psycopg2.connect(
        "dbname=lab4 user=postgres host=localhost password=16142003Da."  #REMEMBER TO CHANGE THE PASSWORD
    )

    return conn

@app.route('/')
def start():
    return render_template('SignUp.html')

@app.route('/', methods=['POST', 'GET'])
def SignUp():
    if request.method == 'POST':
        name = request.form['fullname']
        email = request.form['fullemail']
        user = request.form['usrnme']
        pasww = request.form['pswd']
        pasw = ''
        if re.match('(?=^.{8,}$)(?=.*\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$',pasww):
            pasw = pasww
        else:
            exists = 'WEAK PASSWORD'
            return render_template('SignUp.html', exists = exists)
        conn = get_db_connection()
        cur = conn.cursor()
        # RUN CODE BELOW THE FIRST TIME ONLY
        # cur.execute('CREATE TABLE lab4 (name varchar(500),email varchar(500),username varchar(500),password BYTEA)')
        cur.execute('SELECT * FROM lab4;')
        books = cur.fetchall()
        if name == '' or email == '' or user == '' or pasw == '':
            exists = 'Fields can not be left empty!'
            return render_template('SignUp.html', exists = exists)
        for i in range(0,len(books)):
            if books[i][0] == name and books[i][1] == email:
                exists = 'User already exists, Try login in instead!'
                return render_template('SignUp.html', exists = exists)
        x = bytes(pasw, 'utf-8')
        encPasw = rsa.encrypt(x,publicKey)
        cur.execute('INSERT INTO lab4(name, email, username, password) VALUES(%s, %s, %s, %s)', (name,email,user,encPasw))
        conn.commit()
        cur.execute('SELECT * FROM lab4;')
        books = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('Login.html')

@app.route('/Login')
def Log():
    return render_template('Login.html')


@app.route('/Login', methods=['POST', 'GET'])
def Login():
    message = ''
    if request.method == 'POST':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM lab4')
        books = cur.fetchall()
        user2 = request.form['fullname1']
        pasw2 = request.form['pswrd1']
        for i in range(0,len(books)):
            if books[i][2] == user2:
                x = books[i][3]
                info = rsa.decrypt(x,privateKey).decode()
                if pasw2 == info:
                    cur.close()
                    conn.close()
                    return render_template('Customize.html')
                else:
                    message = 'WRONG USERNAME OR PASSWORD'
                    cur.close()
                    conn.close()
                    return render_template('Login.html', message = message)
        message = 'WRONG USERNAME OR PASSWORD'
        cur.close()
        conn.close()
        return render_template('Login.html', books = books, message = message)

if __name__ == '__main__':
    app.run(debug = True)