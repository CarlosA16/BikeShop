from asyncio.windows_events import NULL
from email import message
from glob import glob
import os
import psycopg2
from flask import Flask, redirect, url_for, render_template, request
from cryptography.fernet import Fernet
import rsa
import re
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

privateKey = RSA.generate(1024)
publicKey = privateKey.publickey()
global encPasw
app = Flask(__name__)
key = Fernet.generate_key()
fernet = Fernet(key)

def get_db_connection():

    conn = psycopg2.connect(
        "dbname=lab4 user=postgres host=localhost password=16142003Da."  #REMEMBER TO CHANGE THE PASSWORD
    )

    return conn

@app.route('/')
def start():
    return render_template('SignUp.html')

@app.route('/', methods=['POST', 'GET'])
def SignUp():
    print('here')
    if request.method == 'POST':
        name = request.form['fullname']
        email = request.form['fullemail']
        user = request.form['usrnme']
        pasww = request.form['pswd']
        pasw = ''
        if re.match('(?=^.{8,}$)(?=.*\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$',pasww):
            pasw = pasww
        else:
            exists = 'WEAK PASSWORD'
            return render_template('SignUp.html', exists = exists)
        conn = get_db_connection()
        cur = conn.cursor()
        # RUN CODE BELOW THE FIRST TIME ONLY
        # cur.execute('CREATE TABLE lab4 (id SERIAL,name varchar(225),email varchar(225),username varchar(225),password varchar(255))')
        cur.execute('SELECT * FROM lab4;')
        books = cur.fetchall()
        
        if name == '' or email == '' or user == '' or pasw == '':
            exists = 'Fields can not be left empty!'
            return render_template('SignUp.html', exists = exists)
        for i in range(0,len(books)):
            if books[i][0] == name and books[i][1] == email:
                exists = 'User already exists, Try login in instead!'
                return render_template('SignUp.html', exists = exists)
        cipher = PKCS1_OAEP.new(key=publicKey)
        global encPasw
        x = bytes(pasw, 'utf-8')
        
        encPasw = cipher.encrypt(x)
        decrypt = PKCS1_OAEP.new(key=privateKey)
        global decoded
        decoded = decrypt.decrypt(encPasw)
        cur.execute('INSERT INTO lab4(name, email, username, password) VALUES(%s, %s, %s, %s)', (name,email,user,encPasw))
        conn.commit()
        cur.execute('SELECT * FROM lab4;')
        books = cur.fetchall()
        cur.close()
        conn.close()
        
        return render_template('Login.html',decoded = decoded)

def encrypt(pasw):
    r = rsa.encrypt(pasw.encode(),
                        publicKey)
    return r

@app.route('/Login')
def Log():
    return render_template('Login.html')


@app.route('/Login', methods=['POST', 'GET'])
def Login():
    final = NULL
    message = ''
    if request.method == 'POST':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM lab4')
        books = cur.fetchall()
        user2 = request.form['fullname1']
        pasw2 = request.form['pswrd1']
       
        for i in range(0,len(books)):
            if books[i][3] == user2:
                decrypt = PKCS1_OAEP.new(key=privateKey)
                print(books[i][4])
                info = decrypt.decrypt((books[i][4]))
                print(str(info))
                info = str(info)
                print(str(pasw2.encode()))
                if info == str(pasw2.encode()):
                    cur.close()
                    conn.close()
                    return render_template('Done.html')
                else:
                    message = 'WRONG USERNAME OR PASSWORD'
                    cur.close()
                    conn.close()
                    return render_template('Login.html', message = message)
        message = 'WRONG USERNAME OR PASSWORD'
        cur.close()
        conn.close()
        return render_template('Login.html', books = books, message = message)

if __name__ == '__main__':
    app.run(debug = True)