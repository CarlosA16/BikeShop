from email import message
from glob import glob
import os
import psycopg2
from flask import Flask, redirect, url_for, render_template, request
import rsa
import re


publicKey = rsa.PublicKey(8864864214230065995202763740218556574899068353919685421281676565235580684818448523110255698019682719811712782298650452722634769219182668510002703110424729, 65537)
privateKey = rsa.PrivateKey(8864864214230065995202763740218556574899068353919685421281676565235580684818448523110255698019682719811712782298650452722634769219182668510002703110424729, 65537, 5138447926669999344275181789880869236725297292044204186698328110230392584069310658951796951190624670637471368763343696551567043315572191461868294028892689, 7179446398685968393772375702460218939053042696689799791218826447466322590177261883, 1234755957764734388111524350388830462126863373341709945592578123205576763)
global encPasw
app = Flask(__name__)

def get_db_connection():

    conn = psycopg2.connect(
        "dbname=postgres user=ashton_w84 host=localhost "  #REMEMBER TO CHANGE THE PASSWORD
    )

    return conn

@app.route('/')
def start():
    return render_template('SignUp.html')

@app.route('/', methods=['POST', 'GET'])
def SignUp():
    if request.method == 'POST':
        name = request.form['fullname']
        email = request.form['fullemail']
        user = request.form['usrnme']
        pasww = request.form['pswd']
        pasw = ''
        if re.match('(?=^.{8,}$)(?=.*\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$',pasww):
            pasw = pasww
        else:
            exists = 'WEAK PASSWORD'
            return render_template('SignUp.html', exists = exists)
        conn = get_db_connection()
        cur = conn.cursor()
        # RUN CODE BELOW THE FIRST TIME ONLY
        # cur.execute('CREATE TABLE lab4 (name varchar(500),email varchar(500),username varchar(500),password BYTEA)')
        cur.execute('SELECT * FROM lab4;')
        books = cur.fetchall()
        if name == '' or email == '' or user == '' or pasw == '':
            exists = 'Fields can not be left empty!'
            return render_template('SignUp.html', exists = exists)
        for i in range(0,len(books)):
            if books[i][0] == name and books[i][1] == email:
                exists = 'User already exists, Try login in instead!'
                return render_template('SignUp.html', exists = exists)
        x = bytes(pasw, 'utf-8')
        encPasw = rsa.encrypt(x,publicKey)
        cur.execute('INSERT INTO lab4(name, email, username, password) VALUES(%s, %s, %s, %s)', (name,email,user,encPasw))
        conn.commit()
        cur.execute('SELECT * FROM lab4;')
        books = cur.fetchall()
        cur.close()
        conn.close()
        return render_template('Login.html')

@app.route('/Login')
def Log():
    return render_template('Login.html')


@app.route('/Login', methods=['POST', 'GET'])
def Login():
    message = ''
    if request.method == 'POST':
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute('SELECT * FROM lab4')
        books = cur.fetchall()
        user2 = request.form['fullname1']
        pasw2 = request.form['pswrd1']
        for i in range(0,len(books)):
            if books[i][2] == user2:
                x = books[i][3]
                info = rsa.decrypt(x,privateKey).decode()
                if pasw2 == info:
                    cur.close()
                    conn.close()
                    return redirect("http://127.0.0.1:5000/bike")
                else:
                    message = 'WRONG USERNAME OR PASSWORD'
                    cur.close()
                    conn.close()
                    return render_template('Login.html', message = message)
        message = 'WRONG USERNAME OR PASSWORD'
        cur.close()
        conn.close()
        return render_template('Login.html', books = books, message = message)

@app.route('/bike')
def bike1():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM bike')
    books = cur.fetchall()
    conn.commit()
    bike = books[0][0]
    bikedesc = books[0][1]
    bikeimg = books[0][2]
    bikeprice = books[0][3]
    bike1 = books[1][0]
    bike1desc = books[1][1]
    bike1img = books[1][2]
    bike1price = books[1][3]
    bike2 = books[2][0]
    bike2desc = books[2][1]
    bike2img = books[2][2]
    bike2price = books[2][3]
    bike3 = books[3][0]
    bike3desc = books[3][1]
    bike3img = books[3][2]
    bike3price = books[3][3]
    bike4 = books[4][0]
    bike4desc = books[4][1]
    bike4img = books[4][2]
    bike4price = books[4][3]
    bike5 = books[5][0]
    bike5desc = books[5][1]
    bike5img = books[5][2]
    bike5price = books[5][3]
    bike6 = books[6][0]
    bike6desc = books[6][1]
    bike6img = books[6][2]
    bike6price = books[6][3]
    bike7 = books[7][0]
    bike7desc = books[7][1]
    bike7img = books[7][2]
    bike7price = books[7][3]
    bike8 = books[8][0]
    bike8desc = books[8][1]
    bike8img = books[8][2]
    bike8price = books[8][3]
    bike9 = books[9][0]
    bike9desc = books[9][1]
    bike9img = books[9][2]
    bike9price = books[9][3]
    print(books[0][0])
    cur.close()
    conn.close()
    return render_template('bike.html',bike=bike,bikedesc=bikedesc,bikeimg=bikeimg,bikeprice=bikeprice,bike1=bike1,bike1desc=bike1desc,bike1img=bike1img,bike1price=bike1price,bike2=bike2,bike2desc=bike2desc,bike2img=bike2img,bike2price=bike2price,bike3=bike3,bike3desc=bike3desc,bike3img=bike3img,bike3price=bike3price,bike4=bike4,bike4desc=bike4desc,bike4img=bike4img,bike4price=bike4price,bike5=bike5,bike5desc=bike5desc,bike5img=bike5img,bike5price=bike5price,bike6=bike6,bike6desc=bike6desc,bike6img=bike6img,bike6price=bike6price,bike7=bike7,bike7desc=bike7desc,bike7img=bike7img,bike7price=bike7price,bike8=bike8,bike8desc=bike8desc,bike8img=bike8img,bike8price=bike8price,bike9=bike9,bike9desc=bike9desc,bike9img=bike9img,bike9price=bike9price,)
    



@app.route('/Customize')
def custom():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM customize')
    books = cur.fetchall()
    conn.commit()
    bike = books[0][0]
    bikedesc = books[0][1]
    bikeimg = books[0][2]
    bikeprice = books[0][3]
    bike1 = books[1][0]
    bike1desc = books[1][1]
    bike1img = books[1][2]
    bike1price = books[1][3]
    bike2 = books[2][0]
    bike2desc = books[2][1]
    bike2img = books[2][2]
    bike2price = books[2][3]
    bike3 = books[3][0]
    bike3desc = books[3][1]
    bike3img = books[3][2]
    bike3price = books[3][3]
    bike4 = books[4][0]
    bike4desc = books[4][1]
    bike4img = books[4][2]
    bike4price = books[4][3]
    bike5 = books[5][0]
    bike5desc = books[5][1]
    bike5img = books[5][2]
    bike5price = books[5][3]
    bike6 = books[6][0]
    bike6desc = books[6][1]
    bike6img = books[6][2]
    bike6price = books[6][3]
    bike7 = books[7][0]
    bike7desc = books[7][1]
    bike7img = books[7][2]
    bike7price = books[7][3]
    bike8 = books[8][0]
    bike8desc = books[8][1]
    bike8img = books[8][2]
    bike8price = books[8][3]
    bike9 = books[9][0]
    bike9desc = books[9][1]
    bike9img = books[9][2]
    bike9price = books[9][3]
    bike10 = books[10][0]
    bike10desc = books[10][1]
    bike10img = books[10][2]
    bike10price = books[10][3]
    bike11 = books[11][0]
    bike11desc = books[11][1]
    bike11img = books[11][2]
    bike11price = books[11][3]
    bike12 = books[12][0]
    bike12desc = books[12][1]
    bike12img = books[12][2]
    bike12price = books[12][3]
    bike13 = books[13][0]
    bike13desc = books[13][1]
    bike13img = books[13][2]
    bike13price = books[13][3]
    bike14 = books[14][0]
    bike14desc = books[14][1]
    bike14img = books[14][2]
    bike14price = books[14][3]
    bike15 = books[15][0]
    bike15desc = books[15][1]
    bike15img = books[15][2]
    bike15price = books[15][3]
    bike16 = books[16][0]
    bike16desc = books[16][1]
    bike16img = books[16][2]
    bike16price = books[16][3]
    bike17 = books[17][0]
    bike17desc = books[17][1]
    bike17img = books[17][2]
    bike17price = books[17][3]
    cur.close()
    conn.close()
    return render_template('Customize.html',bike=bike,bikedesc=bikedesc,bikeimg=bikeimg,bikeprice=bikeprice,bike1=bike1,bike1desc=bike1desc,bike1img=bike1img,bike1price=bike1price,bike2=bike2,bike2desc=bike2desc,bike2img=bike2img,bike2price=bike2price,bike3=bike3,bike3desc=bike3desc,bike3img=bike3img,bike3price=bike3price,bike4=bike4,bike4desc=bike4desc,bike4img=bike4img,bike4price=bike4price,bike5=bike5,bike5desc=bike5desc,bike5img=bike5img,bike5price=bike5price,bike6=bike6,bike6desc=bike6desc,bike6img=bike6img,bike6price=bike6price,bike7=bike7,bike7desc=bike7desc,bike7img=bike7img,bike7price=bike7price,bike8=bike8,bike8desc=bike8desc,bike8img=bike8img,bike8price=bike8price,bike9=bike9,bike9desc=bike9desc,bike9img=bike9img,bike9price=bike9price,bike10=bike10,bike10desc=bike10desc,bike10img=bike10img,bike10price=bike10price,bike11=bike11,bike11desc=bike11desc,bike11img=bike11img,bike11price=bike11price,bike12=bike12,bike12desc=bike12desc,bike12img=bike12img,bike12price=bike12price,bike13=bike13,bike13desc=bike13desc,bike13img=bike13img,bike13price=bike13price,bike14=bike14,bike14desc=bike14desc,bike14img=bike14img,bike14price=bike14price,bike15=bike15,bike15desc=bike15desc,bike15img=bike15img,bike15price=bike15price,bike16=bike16,bike16desc=bike16desc,bike16img=bike16img,bike16price=bike16price,bike17=bike17,bike17desc=bike17desc,bike17img=bike17img,bike17price=bike17price)

@app.route('/cart')
def cartPage():
    return render_template('cart.html')


if __name__ == '__main__':
    app.run(debug = True)




